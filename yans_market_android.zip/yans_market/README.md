# Yans Market — Android app starter

A dark graphite/yellow Expo React Native storefront prototype.

## Run locally
1. Install Node.js (LTS).
2. In this folder run `npm install`.
3. Run `npx expo start`.
4. Open with Expo Go on Android, or press `a` with Android tooling installed.

## Before public launch
- Replace demo products, prices, and descriptions with verified listings.
- Add real affiliate URLs to each product and implement link opening.
- Add the real Telegram/support contact and privacy policy.
- Confirm affiliate-program rules and required advertising disclosures.
- Configure an EAS Android build and Google Play developer account if publishing to Play Store.

This is a functional UI prototype with local in-memory cart/favorites; it does not yet process payments, store user accounts, or connect to a product database.

## Build an installable Android APK (Expo EAS)
1. Install Node.js LTS and EAS CLI: `npm install -g eas-cli`.
2. From this folder run `npm install`.
3. Sign in to your Expo account: `eas login`.
4. Configure the project once: `eas build:configure`.
5. Build an APK: `eas build --platform android --profile preview`.
6. When the cloud build finishes, download the APK from the build link printed by EAS.

The `preview` profile is configured to produce an APK. A signed APK cannot be generated in this workspace because Android SDK/Gradle and an authenticated Expo EAS build account are not available here.
